const DIM = 5;
const BOMBS = 5;
let cont = 0;

window.addEventListener("load", function(){
    creaTab();
    riempiBombe();
});

function creaTab(){
    const wrapper = document.getElementById("wrapper");
    for(let i = 0; i < DIM; i++)
    {
        for (let j = 0; j < DIM; j++) {
            let btn = document.createElement("button");

            btn.id = `btn-${i}-${j}`;
            btn.addEventListener("click", clickBtn);
            btn.dataset.bomba = "0";
            btn.style.backgroundColor = "#DDDDDD";

            wrapper.appendChild(btn);
        }
    }
}

function riempiBombe(){
    for (let i = 0; i < BOMBS; i++) {
        let row = 0, col = 0, btn;
        do{
            row = Math.floor(Math.random()*5);
            col = Math.floor(Math.random()*5);
            btn = document.getElementById(`btn-${row}-${col}`);
        }while(btn.dataset.bomba == "-1");
        btn.dataset.bomba = "-1";

        //upper row
        if(row > 0)
        {
            if(col > 0)
            {
                add(row-1,col-1);
            }
            add(row-1,col);
            if(col < DIM-1)
            {
                add(row-1,col+1);
            }
        }
        //lower row
        if(row < DIM-1)
        {
            if(col > 0)
            {
                add(row+1,col-1);
            }
            add(row+1,col);
            if(col < DIM-1)
            {
                add(row+1,col+1);
            }
        }
        //left
        if(col > 0)
        {
            add(row,col-1);
        }
        //right
        if(col < DIM-1)
        {
            add(row,col+1);
        }
    }
}

function add(row, col){
    const btn = document.getElementById(`btn-${row}-${col}`);
    if(btn.dataset.bomba != "-1")
    {
        btn.dataset.bomba = parseInt(btn.dataset.bomba) + 1;
    }
}

function clickBtn(){
    this.disabled = true;
    cont++;
    if(this.dataset.bomba == "-1"){
        this.style.backgroundImage = `url(bomba.png)`;
        alert("Hai perso");
        lock();
    } else{
        this.style.backgroundColor = "#FFFFFF";
        if(this.dataset.bomba != "0")
        {
            this.innerText = this.dataset.bomba;
        }
        this.removeEventListener("click", clickBtn);
    }
    if(cont == 20)
    {
        alert("Hai vinto!");
        lock();
    }
}

function lock(){
    for (let i = 0; i < DIM; i++){
        for (let j = 0; j < DIM; j++) {
            const btn = document.getElementById(`btn-${i}-${j}`);
            btn.removeEventListener("click", clickBtn);
            btn.disabled = true;
            if(btn.dataset.bomba == "-1")
            {
                btn.style.backgroundImage = "url(bomba.png)";
            }
        }
    }
}